# webfonts-core
Standard webfonts and associated CSS for a pankosmia-web server
