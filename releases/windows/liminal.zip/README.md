#USAGE

To upgrade:

1. Backup `~/panksomia_working/repos` where "~" is the OS user home directory.
2. Delete `~/panksomia_working/`
3. Run the server: `.\liminal.bat` (Or double-click `liminal.bat` in Windows File Explorer)
4. Restore backup from step 1 to `~/panksomia_working/repos`
5. Then connect to http://localhost:8000

First use:

1. Run the server: `.\liminal.bat` (Or double-click `liminal.bat` in Windows File Explorer)
2. Then connect to http://localhost:8000

Best viewed with a Graphite-enabled browser such as Firefox.
