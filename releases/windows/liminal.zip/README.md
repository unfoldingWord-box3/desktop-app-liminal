#USAGE

Run the server: `.\liminal.bat`
(Or double-click `liminal.bat` in Windows File Explorer)

Then connect to http://localhost:8000

Best viewed with a Graphite-enabled browser such as Firefox.
